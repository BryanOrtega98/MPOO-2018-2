//
//  ViewController.swift
//  game
//
//  Created by macbook on 28/02/18.
//  Copyright © 2018 bryancompany. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var numero1: UITextField!
    @IBOutlet weak var numero2: UITextField!
    @IBOutlet weak var resultado: UILabel!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    @IBAction func suma(_ send: Any ) {
        let one = Int(numero1.text!)
        let two = Int(numero2.text!)
        if one == nil || two == nil {
            print("llena todos los recuadros")
        }
        resultado.text = String (one! + two!)
    }
        
        @IBAction func resta(_ sender: Any) {
            let one = Int(numero1.text!)
            let two = Int(numero2.text!)
            if one == nil || two == nil {
                print("llena todos los recuadros")
            }
            resultado.text = String (one! - two!)
        }
        
}


