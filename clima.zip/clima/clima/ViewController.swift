//
//  ViewController.swift
//  clima
//
//  Created by macbook on 07/03/18.
//  Copyright © 2018 Bryancompany. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var control: UISlider!
    @IBOutlet weak var tiempo: UILabel!
    @IBOutlet weak var imaen: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func climaControl(_ sender: UISlider) {
        var x: Float
        x = control.value
        view.backgroundColor = UIColor (displayP3Red: 3, green: CGFloat(x/100), blue: (2), alpha: CGFloat(1))
        print(x)
        switch x {
        case -1.5...0:
            tiempo.text = "LLUVIOSO"
            imaen.image = #imageLiteral(resourceName: "lluvia")
            
        case 0.1...1.5:
            tiempo.text = "NUBLADO"
            imaen.image = #imageLiteral(resourceName: "nublado")
            
        case 1.6...3:
            tiempo.text = "DESPEJADO"
            imaen.image = #imageLiteral(resourceName: "despejado")
        case 3.1...4.5:
            tiempo.text = "SOLEADO"
            imaen.image = #imageLiteral(resourceName: "soleado")
        default:
            imaen.image = #imageLiteral(resourceName: "huracan")
            
        }
    }
    

}

